package com.trg.course.controller;

import com.trg.course.entity.Course;
import com.trg.course.exception.CourseAlreadyExistsException;
import com.trg.course.exception.CourseNotFoundException;
import com.trg.course.service.CourseService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    CourseService courseService;

	/*@ExceptionHandler(value = CourseNotFoundException.class)
	public ResponseEntity handleMyException(CourseNotFoundException ce) {
        return new ResponseEntity("Course Not found", HttpStatus.CONFLICT);
    }*/

    //@CrossOrigin(origins="http://localhost:4200/")
    @GetMapping("/courses")
    public List<Course> getCourses() {
        return courseService.getCourses();
    }


    @GetMapping("/courses/{id}")
    public ResponseEntity getById(@PathVariable int id)  {
        try{
            return new ResponseEntity(courseService.getCourseById(id), HttpStatus.OK);
        }
        catch(CourseNotFoundException e){
            return new ResponseEntity(e.getMessage(), HttpStatus.CONFLICT);
        }
    }


	//@CrossOrigin(origins="http://localhost:4200/")
	/*@GetMapping("/courses/{id}")
	public Course getById(@PathVariable int id) throws CourseNotFoundException {
		System.out.println("In getById() ctrlr");
		return courseService.getCourseById(id);
	}*/

    @DeleteMapping("/courses/{id}")
    public void delCourse(@PathVariable int id) throws CourseNotFoundException {
        courseService.deleteCourse(id);
    }

    @PostMapping("/courses")
    public Course addCourse(@Valid @RequestBody Course course) throws CourseAlreadyExistsException {
        return courseService.addCourse(course);
    }


    //@CrossOrigin(origins="http://localhost:4200/")
    /*@PostMapping("/courses")
    public ResponseEntity<Object> addCourse(@Valid @RequestBody Course course) {
        try {
            return new ResponseEntity(courseService.addCourse(course), HttpStatus.OK);
        }
        catch(CourseAlreadyExistsException e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
            }
    }*/

    @PutMapping("/courses/{id}")
    public void updateCourse(@PathVariable int id,
                             @RequestBody Course course){
        courseService.updateCourse(id, course);
    }

    /*@DeleteMapping("/courses/{id}")
    public void delCourse(@PathVariable int id) throws CourseNotFoundException {
        courseService.deleteCourse(id);
    }*/

	/*@GetMapping(value = "/{id}", produces = "application/json")
	public Course getCourseById(@PathVariable int cid) {
		return courseService.getCourseById(cid);
	}*/
}
