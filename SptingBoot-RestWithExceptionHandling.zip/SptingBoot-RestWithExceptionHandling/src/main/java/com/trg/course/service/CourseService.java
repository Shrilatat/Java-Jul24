package com.trg.course.service;

import com.trg.course.entity.Course;
import com.trg.course.exception.CourseAlreadyExistsException;
import com.trg.course.exception.CourseNotFoundException;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

@Service
public class CourseService {

    public CourseService() {
        courses.add(new Course(101, "Spring", "Spring quickstart"));
        courses.add(new Course(102, "Java", "Java fundamentals"));
        courses.add(new Course(103, "NodeJS", "Node essentials"));
    }

    List<Course> courses = new ArrayList<>();

    public List<Course> getCourses() {
        return courses;
    }

    public Course getCourseById(int id) throws CourseNotFoundException {
        Course found = null;
        boolean flag = false;
        for (Course c : courses) {
            if (c.getId() == id) {
                found = c;
                flag = true;
                break;
            }
        }
        if (flag)
            return found;
        else throw new CourseNotFoundException("Course","id", (long) id);
    }


	/*public Course getCourseById(int id) {
		for(Course c : courses){
			if(c.getId()==id){
				return c;
			}
		}
		return null;
	}*/


    public Course addCourse(Course course) throws CourseAlreadyExistsException {
        for (Course c : courses) {
            if (c.getId() == course.getId())
                throw new CourseAlreadyExistsException("Course with id " + course.getId() + " already exists");
        }
        courses.add(course);
        return course;
    }

    public void updateCourse(int id, Course course) {
        System.out.println(id);
        for (int i = 0; i < courses.size(); i++) {
            if (courses.get(i).getId() == id) {
                courses.set(i, course);
                break;
            }
        }
    }

    public void deleteCourse(int id) throws CourseNotFoundException {
        Iterator<Course> it = courses.iterator();
        boolean flag=false;
        while (it.hasNext()) {
            if (it.next().getId() == id) {
                flag=true;
                it.remove();
                break;
            }
            if(!flag)
            throw new CourseNotFoundException("Course","id", (long) id);
        }
    }

}