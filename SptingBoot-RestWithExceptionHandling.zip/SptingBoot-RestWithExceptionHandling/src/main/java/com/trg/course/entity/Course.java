package com.trg.course.entity;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

public class Course {

    @NotNull(message = "Id is required.")
    int id;

    @Size(min = 3, max = 20, message = "The length of name must be between 3 and 20 characters.")
    @NotBlank
    String name;

    @Size(min = 5, max = 50, message = "The length of description must be between 5 and 50 characters.")
    @NotBlank
    String desc;

    // appropriate cons,getter,setter

    public Course() {
    }

    public Course(int id, String name, String desc) {
        super();
        this.id = id;
        this.name = name;
        this.desc = desc;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    @Override
    public String toString() {
        return "Course [id=" + id + ", name=" + name + ", desc=" + desc + "]";
    }

}

