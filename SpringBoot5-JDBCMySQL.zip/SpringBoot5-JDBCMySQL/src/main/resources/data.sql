/* data.sql */
insert into server values(1,'Shri-server','192.168.22.01', 'Pune');
insert into server values(2,'bkp-server','192.168.22.22', 'Pune');
insert into server values(3,'db-server','192.150.01.11', 'Blr');
insert into server values(4,'Admin','192.168.22.11', 'Mumbai');