import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link } from 'react-router-dom';
import CourseService from './service/CourseService';

function CourseList() {
    const [courses, setCourses] = useState([]);
    const baseUrl = 'http://localhost:8080/course/courses'

    useEffect(() => {
        CourseService.getCourses()
            //axios.get(baseUrl)
            .then(response => {
                setCourses(response.data);
            })
            .catch(error => {
                console.log(error);
            });
    }, []);

    const fetchdata = () => {
        CourseService.getCourses()
            .then((result) => {
                console.log(result.data);
                setCourses(result.data)
                //this.setState({...this.state,earr:result.data,searcharr:result.data})
            })
            .catch(error => {
                console.log(error);
            })
    }

    const deleteCourse = (id) => {
        CourseService.deleteById(id)
            .then(() => {
                //it sends get request to webservice to get new list of courses
                fetchdata();
            })
            .catch(error => {
                console.log(error);
            })
    }



    return (
        <div>
            <table className="table table-bordered table-striped">
                <thead className="thead-dark">
                    <tr className="table-warning">
                        <th>Course ID</th><th>Course Name</th><th>Course Desc</th><th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    {courses.map(course => (
                        <tr>
                            <td> {course.id}</td>
                            <td>{course.name}</td>
                            <td>{course.desc}</td>

                            <td>
                                <button type="button" id="btn" name="btn" className="btn btn-danger" onClick={() => { deleteCourse(course.id) }} >Delete</button>
                                &nbsp;&nbsp;&nbsp;
                                <Link to={`/courseEdit/${course.id}`} state={{ course: course }}>
                                    <button type="button" id="btn" name="btn" className="btn btn-primary">Update</button>
                                </Link>
                            </td>

                        </tr>
                    ))}
                </tbody>
            </table>
           <br></br>
            <Link to={`/courseForm`} >
                <button type="button" id="btn" name="btn" className="btn btn-primary">Add</button>
            </Link>
        </div>
    )
}

export default CourseList
