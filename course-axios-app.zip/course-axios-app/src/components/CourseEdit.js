import { useEffect, useState } from "react"
import { useLocation, useNavigate, useParams } from 'react-router-dom'
import CourseService from "./service/CourseService";


const CourseEdit = (props) => {

    // this helps to retrieve parameters
    const params = useParams();

    //it helps to retrieve state object coming via Link
    const location = useLocation()

    //its a hook which gives access to navigate object used for changing the url
    let navigate = useNavigate()

    let [formdetails, setformdetails] = useState({ id: "", name: "", desc: "" });

    useEffect(() => {
        setformdetails({ ...location.state.course })
    }, [])

    let updateCourse = () => {
        console.log("in update course")
        CourseService.updateCourse(formdetails)
            .then(() => {
                navigate("/courseList")
            })
            .catch((err) => {
                console.log("error occured", err);
            })
    }
    console.log("in course edit");
    console.log(location.state.course)

return (
    <div>
        <form>
            <div className="form-group">
                <label htmlFor="id">Course id</label>
                <input className="form-control" id="id" name="id"
                    value={formdetails.id}
                   readOnly
                />

            </div>
            <div className="form-group">
                <label htmlFor="name">Course Name</label>
                <input className="form-control" id="name" name="name"
                    value={formdetails.name}
                    onChange={(event) => { setformdetails({ ...formdetails, name: event.target.value }) }}
                />
            </div>
            <div className="form-group">
                <label htmlFor="desc">Course Desc</label>
                <input className="form-control" id="desc" name="desc"
                    value={formdetails.desc}
                    onChange={(event) => { setformdetails({ ...formdetails, desc: event.target.value }) }}
                />
            </div>
            <button type="button" className="btn btn-primary" onClick={updateCourse}>Update Course</button>
        </form>
    </div>
)
}


export default CourseEdit