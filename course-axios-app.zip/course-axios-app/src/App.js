import logo from './logo.svg';
import './App.css';
import NavBar from './components/NavBar';
import { Route, Routes } from 'react-router-dom';
import Home from './components/Home';
import CourseList from './components/CourseList';
import CourseEdit from './components/CourseEdit';
import CourseForm from './components/CourseForm';

function App() {
  return (
    <div className="App">
      <NavBar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/courseList" element={<CourseList />} />
        <Route path="/CourseEdit/:cid" element={<CourseEdit />} />
        <Route path="/courseForm" element={<CourseForm />} />
      </Routes>
    </div>
  );
}

export default App;
