package com.trg.course.courseConsumer;

import com.trg.course.entity.Course;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.MediaType;
import org.springframework.web.client.RestClient;

import java.util.List;

public class CourseRestClientApp {
    private final RestClient restClient;

    public CourseRestClientApp() {
        restClient = RestClient.builder()
                .baseUrl("http://localhost:8080/course")
                .build();
    }

    public void getCourseById() {

        int cid=102;
        Course c = restClient.get()
                .uri("/courses/{id}", cid)
                .retrieve()
                .body(Course.class);
        System.out.println(c);
    }

    public void findAll() {
        List<Course> courseList = restClient.get()
                .uri("/courses")
                .retrieve()
                .body(new ParameterizedTypeReference<List<Course>>() {});

        courseList.forEach(course -> {
            System.out.println(course);
        });
    }
    public void createCourse() {
        Course c = new Course(106,"AWS","AWS desc");
        Course newCourse = restClient.post()
                .uri("/courses")
                .contentType(MediaType.APPLICATION_JSON)
                .body(c)
                .retrieve()
                .body(Course.class);

        System.out.println(newCourse);
    }

    public void deleteCourse() {
        int cid = 102;

        String response = restClient.delete()
                .uri("/courses/{id}", cid)
                .retrieve()
                .body(String.class);

        System.out.println(response);
    }
    public static void main(String[] args) {
        var app = new CourseRestClientApp();
        app.findAll();
        System.out.println("--------");
        app.createCourse();
        app.getCourseById();
        System.out.println("--------");
        app.findAll();
        app.deleteCourse();
        System.out.println("--------");
        app.findAll();
    }
}
