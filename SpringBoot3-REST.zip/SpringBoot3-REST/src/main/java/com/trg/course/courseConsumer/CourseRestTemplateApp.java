package com.trg.course.courseConsumer;

import com.trg.course.entity.Course;
import org.springframework.web.client.RestTemplate;

import java.util.LinkedHashMap;
import java.util.List;

public class CourseRestTemplateApp {

    static final String REST_URI = "http://localhost:8080/course";

    static RestTemplate restTemplate = new RestTemplate();

    private static void listAllCourses() {
        System.out.println("\n Testing listAllPersons API-----------");
        List<LinkedHashMap<String, Object>> coursesMap =
                restTemplate.getForObject(REST_URI + "/courses", List.class);

        if (coursesMap != null) {
            for (LinkedHashMap<String, Object> map : coursesMap)
                System.out.println("Course : id=" + map.get("id") +
                        ", name=" + map.get("name") +
                        ", Desc=" + map.get("desc"));
        } else
            System.out.println("No course exists----------");
    }

    private static void getCourse(int id) {
        System.out.println("\n Testing getPerson API----------");
        Course course =
                restTemplate.getForObject(REST_URI + "/courses/" + id, Course.class);
        System.out.println(course);
    }

    private static void createCourse(Course c) {
        System.out.println("\n Testing create Course API----------");
        Course course =
                restTemplate.postForObject(REST_URI + "/courses", c, Course.class);
        System.out.println("Newly created course : " + course);
    }

    private static void deleteCourse(int id) {
        System.out.println("\n Testing delete Course API----------");
        restTemplate.delete(REST_URI + "/courses/" + id);
    }

    private static void updateCourse(int id, Course c) {
        System.out.println("\n Testing update Course API----------");
        restTemplate.put(REST_URI + "/courses"+ id, c);
    }

    public static void main(String args[]) {
        listAllCourses();
        getCourse(101);
        Course c = new Course(105,"ReactJS","React desc");
        createCourse(c);
        listAllCourses();
        deleteCourse(101);
        listAllCourses();
        //Course c1 = new Course(105,"ReactJS","React Beginner version");
        //updateCourse(105,c1);
        //listAllCourses();

    }
}
