package com.trg.course.exception;

public class CourseAlreadyExistsException extends Exception {
    public CourseAlreadyExistsException() {
        super();
    }

    public CourseAlreadyExistsException(String message) {
        super(message);
    }
}
