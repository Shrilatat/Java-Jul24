package com.trg.course.controller;

import com.trg.course.entity.Course;
import com.trg.course.exception.CourseAlreadyExistsException;
import com.trg.course.exception.CourseNotFoundException;
import com.trg.course.service.CourseService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/course")
public class CourseController {
    @Autowired
    CourseService courseService;

    @GetMapping("/courses")
    public List<Course> getCourses() {
        return courseService.getCourses();
    }

	//@CrossOrigin(origins="http://localhost:4200/")
	@GetMapping("/courses/{id}")
	public Course getById(@PathVariable int id) throws CourseNotFoundException {
		System.out.println("In getById() ctrlr");
		return courseService.getCourseById(id);
	}

    @PostMapping("/courses")
    public ResponseEntity<Object> addCourse(@RequestBody Course course) {
        try {
            return new ResponseEntity(courseService.addCourse(course), HttpStatus.OK);
        }
        catch(CourseAlreadyExistsException e){
            return new ResponseEntity<>(e.getMessage(), HttpStatus.CONFLICT);
            }
    }

    @PutMapping("/courses/{id}")
    public void updateCourse(@PathVariable int id,
                             @RequestBody Course course){
        courseService.updateCourse(id, course);
    }

    @DeleteMapping("/courses/{id}")
    public void delCourse(@PathVariable int id) throws CourseNotFoundException {
        courseService.deleteCourse(id);
    }
}
