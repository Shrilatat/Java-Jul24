package com.trg.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class User{
    private String name;
    private String password;
    public User(String name, String password) {
        this.name = name;
        this.password = password;
    }
    public String getName() {
        return name;
    }
    public String getPassword() {return password;}

    @Override
    public String toString() {
        return "User{" +
                "name='" + name + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
@Controller
@ResponseBody
public class HelloController {

    List<User> users = Arrays.asList(new User("Shrilata","secret"), new User("sandeep","s123"), new User("admin","admin"), new User("user","user"));

    @RequestMapping("/")
    public String m1(){
        return "Hello, welcome to REST";
    }

    @RequestMapping("/user/{uname}")
    public User UserData(@PathVariable String uname){
        for(User user : users){
            if(user.getName().equals(uname))
                return user;
        }
        return null;
    }

    @RequestMapping("/userNames")
    public String[] UserNames(){
        String names[] = {"aaa","bbb","ccc"};
        return names;
    }

    @RequestMapping("/users")
    public List<User> Users(){

        return users;
    }

}


