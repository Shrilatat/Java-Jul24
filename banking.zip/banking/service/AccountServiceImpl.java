package com.banking.service;

import com.banking.dao.AccountDao;
import com.banking.exception.AccountNotExistException;
import com.banking.factory.AccountStoreFactory;
import com.banking.model.Account;

public class AccountServiceImpl implements AccountService{

    AccountDao dao = AccountStoreFactory.getDaoImpl("array");

    @Override
    public Account getAccountById(int id) throws AccountNotExistException {
       return dao.getAccountById(id);
    }

    @Override
    public Account[] getAllAccounts() {
        return new Account[0];
    }

    @Override
    public void addAccount(Account account) {

    }

    @Override
    public void delAccount(int id) {

    }

    @Override
    public void updateAccount(Account account) {

    }
}
