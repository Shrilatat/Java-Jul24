package com.banking.service;

import com.banking.exception.AccountNotExistException;
import com.banking.model.Account;

public interface AccountService {
    public Account getAccountById(int id) throws AccountNotExistException;
    public Account[] getAllAccounts();
    public void addAccount(Account account);
    public void delAccount(int id);
    public void updateAccount(Account account) ;
}
