package com.banking.exception;

public class AccountNotExistException extends Exception{
    public AccountNotExistException() {
    }

    public AccountNotExistException(String message) {
        super(message);
    }

    public AccountNotExistException(String message, Throwable cause) {
        super(message, cause);
    }

    public AccountNotExistException(Throwable cause) {
        super(cause);
    }

    public AccountNotExistException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
        super(message, cause, enableSuppression, writableStackTrace);
    }
}
