package com.banking.dao;

import com.banking.exception.AccountNotExistException;
import com.banking.model.Account;
import com.banking.model.SavingAccount;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class AccountDaoListImpl implements AccountDao {

    List<Account> acctList = new ArrayList<>();

    public AccountDaoListImpl() {
        acctList.add(new Account(101,"Shrilata", 50000));
        acctList.add(new SavingAccount(102,"Driti", 40000, 7.5));
        acctList.add(new Account(103,"Vedant", 20000));
        acctList.add(new SavingAccount(104,"Harshal", 70000, 5.5));
        acctList.add(new Account(105,"Kulmeet", 30000));
    }

    @Override
    public Account getAccountById(int id) throws AccountNotExistException {
        for(Account acct : acctList){
            if(acct.getAcctId() == id)
                return acct;
        }
        throw new AccountNotExistException("Acccount with id " + id + " not found");
    }

    @Override
    public Account[] getAllAccounts() {
        return (acctList.toArray(new Account[0]));
    }

    @Override
    public void addAccount(Account account) {
        acctList.add(account);
    }

    @Override
    public void delAccount(int id) throws AccountNotExistException {
        boolean flag = false;

        Iterator<Account> it = acctList.iterator();
        while(it.hasNext()){
            Account acct = it.next();
            if(acct.getAcctId() == id) {
                it.remove();
                return;
            }
        }
        throw new AccountNotExistException();
    }

    @Override
    public void updateAccount(Account account) {

    }
}
