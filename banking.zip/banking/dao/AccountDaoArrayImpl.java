package com.banking.dao;

import com.banking.exception.AccountNotExistException;
import com.banking.model.Account;
import com.banking.model.SavingAccount;

import java.util.Arrays;

public class AccountDaoArrayImpl implements AccountDao{

    Account[] acctArr = new Account[5];

    public AccountDaoArrayImpl() {
        acctArr[0] = new Account(101,"Shrilata", 50000);
        acctArr[1] = new SavingAccount(102,"Driti", 40000, 7.5);
        acctArr[2] = new Account(103,"Vedant", 20000);
        acctArr[3] = new SavingAccount(104,"Harshal", 70000, 5.5);
        acctArr[4] = new Account(105,"Kulmeet", 30000);
    }

    @Override
    public Account getAccountById(int id) throws AccountNotExistException {
        for(Account acct : acctArr){
            if(acct.getAcctId() == id)
                return acct;
        }
        throw new AccountNotExistException("In Dao : Account with id " + id + " does not exist");
    }

    @Override
    public Account[] getAllAccounts() {
        return acctArr;
    }

    @Override
    public void addAccount(Account account) {
        acctArr = Arrays.copyOf(acctArr, acctArr.length+1 );
        acctArr[acctArr.length-1] = account;
    }

    @Override
    public void delAccount(int id) {

    }

    @Override
    public void updateAccount(Account account)  {
        for(Account acct : acctArr){
            if(acct.getAcctId() == account.getAcctId()){
                acct.setAcctName(account.getAcctName());
                acct.setBal(account.getBal());
            }
        }
    }
}
