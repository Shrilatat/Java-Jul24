package com.banking.dao;

import com.banking.exception.AccountNotExistException;
import com.banking.model.Account;

public interface AccountDao {

    //CRUD ops
    public Account getAccountById(int id) throws AccountNotExistException;
    public Account[] getAllAccounts();
    public void addAccount(Account account);
    public void delAccount(int id) throws AccountNotExistException;
    public void updateAccount(Account account) ;
}
