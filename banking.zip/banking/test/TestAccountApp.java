package com.banking.test;

import com.banking.ui.AccountUI;

import java.util.Scanner;

public class TestAccountApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Which DAO impl?(array/collection/db)");
        String type = sc.next();
        new AccountUI(type);
    }
}
