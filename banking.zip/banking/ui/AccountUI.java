package com.banking.ui;

import com.banking.dao.AccountDao;
import com.banking.dao.AccountDaoArrayImpl;
import com.banking.exception.AccountNotExistException;
import com.banking.factory.AccountStoreFactory;
import com.banking.model.Account;
import com.banking.model.SavingAccount;

import java.util.Scanner;

public class AccountUI {

    AccountDao dao = null;

    public AccountUI(String type) {
        dao = AccountStoreFactory.getDaoImpl(type);
        displayMenu();
    }

    public void displayMenu() {
        Scanner sc = new Scanner(System.in);
        while (true) {
            System.out.println("1. Display Account with ID");
            System.out.println("2. Display All Accounts");
            System.out.println("3. Add Account ");
            System.out.println("4. Update Account");
            System.out.println("5. Delete Account");
            System.out.println("6. Exit Application");

            System.out.println("Enter your choice: ");
            int choice = sc.nextInt();
            switch (choice) {
                case 1:
                    System.out.println("Enter ID to fetch account :");
                    int id = sc.nextInt();
                    Account acct = null;
                    try {
                        acct = dao.getAccountById(id);
                    } catch (AccountNotExistException e) {
                        System.out.println(e.getMessage());
                    }
                    if (acct != null)
                        acct.displayAccountDetails();
                    break;
                case 2:
                    Account[] allaccts = dao.getAllAccounts();
                    for (Account a : allaccts) {
                        a.displayAccountDetails();
                    }
                    break;
                case 3:
                    dao.addAccount(acceptDetails(sc));
                    break;
                case 4:
                    System.out.println("Enter ID to Update account :");
                    int id1 = sc.nextInt();
                    Account acct1 = null;
                    try {
                        acct1 = dao.getAccountById(id1);
                    } catch (AccountNotExistException e) {
                        System.out.println(e.getMessage());
                    }
                    if (acct1 != null)
                        dao.updateAccount(updateDetails(sc, id1));
                    break;
                case 5:
                    System.out.println("delete not supported!");
                    break;
                case 6:
                    sc.close();
                    System.exit(0);
            }
        }
    }
        private Account acceptDetails (Scanner sc){
            Account a = null;

            System.out.println("Enter Account id :");
            int id = sc.nextInt();
            System.out.println("Enter Account Name : ");
            String aname = sc.next();
            System.out.println("Enter Bal :");
            double bal = sc.nextDouble();
            System.out.println("Enter Account type (account/saving)");
            String type = sc.next();
            if (type.equals("saving")) {
                System.out.println("Enter Interest Rate :");
                double rate = sc.nextDouble();
                a = new SavingAccount(id, aname, bal, rate);
            } else
                a = new Account(id, aname, bal);
            return a;
        }

    private Account updateDetails (Scanner sc, int id){
        Account a = null;
        System.out.println("Enter Account Name : ");
        String aname = sc.next();
        System.out.println("Enter Bal :");
        double bal = sc.nextDouble();
        a = new Account(id, aname, bal);
        return a;
    }
}
