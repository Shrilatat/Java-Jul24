package com.banking.model;

public class SavingAccount extends  Account{
    double interestRate;

    public SavingAccount(int acctId, String acctName, double bal, double interestRate) {
        super(acctId, acctName, bal);
        this.interestRate = interestRate;
    }
}
