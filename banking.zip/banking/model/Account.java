package com.banking.model;

public class Account {
    private int acctId;
    private String acctName;
    private double bal;

    public Account() {
    }

    public Account(int acctId, String acctName, double bal) {
        this.acctId = acctId;
        this.acctName = acctName;
        this.bal = bal;
    }

    public int getAcctId() {
        return acctId;
    }

    public void setAcctId(int acctId) {
        this.acctId = acctId;
    }

    public String getAcctName() {
        return acctName;
    }

    public void setAcctName(String acctName) {
        this.acctName = acctName;
    }

    public double getBal() {
        return bal;
    }

    public void setBal(double bal) {
        this.bal = bal;
    }

    public void displayAccountDetails() {
        System.out.println( "Account{" +
                "acctId=" + acctId +
                ", acctName='" + acctName + '\'' +
                ", bal=" + bal +
                '}');
    }
}
