package com.banking.factory;

import com.banking.dao.AccountDao;
import com.banking.dao.AccountDaoArrayImpl;
import com.banking.dao.AccountDaoListImpl;

public class AccountStoreFactory {

    AccountDao dao = null;

    public static AccountDao getDaoImpl(String type){
        if(type.equals("array"))
            return new AccountDaoArrayImpl();
        else if(type.equals("list"))
            return new AccountDaoListImpl();
        else if(type.equals("db"));
               // return new AccountDaoDBImpl();
        return null;
    }
}
