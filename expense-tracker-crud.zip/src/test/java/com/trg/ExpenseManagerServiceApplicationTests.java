package com.trg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseManagerServiceApplicationTests {

    @Test
    void contextLoads() {
    }

}
