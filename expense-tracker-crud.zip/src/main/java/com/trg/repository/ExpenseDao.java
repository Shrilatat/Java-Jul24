package com.trg.repository;

import com.trg.entity.ExpenseItem;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ExpenseDao  extends JpaRepository<ExpenseItem, Integer> {

}
