package com.trg.resource;

import com.trg.entity.ExpenseItem;
import com.trg.service.ExpenseCRUDService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/expenseManagerCRUD")
public class ExpenseManagerCRUDResource {

    @Autowired
    ExpenseCRUDService service;

    @GetMapping("/expenses/{id}")
    public ExpenseItem getItemById(@PathVariable int id) {
        return service.getItemById(id);
    }

    @GetMapping("/expenses")
    public List<ExpenseItem> getItems() {
        return service.getItems();
    }

    @PostMapping("/expenses")
    public ExpenseItem createItem(@RequestBody ExpenseItem item) {
        System.out.println("In controller "  + item);
        return service.saveItem(item);
    }

    @DeleteMapping("/expenses/{id}")
    public void deleteItem(@PathVariable int id) {
        service.deleteItemById(id);
    }

    @PutMapping("/expenses/{id}")
    public ExpenseItem updateItem(@RequestBody ExpenseItem item) {
        return service.updateItem(item);
    }
}
