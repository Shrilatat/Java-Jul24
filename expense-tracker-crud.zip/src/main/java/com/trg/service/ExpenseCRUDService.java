package com.trg.service;

import com.trg.entity.ExpenseItem;
import com.trg.exception.ExpenseItemNotFoundException;
import com.trg.repository.ExpenseDao;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.server.ResponseStatusException;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class ExpenseCRUDService {

    @Autowired
    ExpenseDao dao;

    public ExpenseItem getItemById(int id) {
        return dao.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, String.format("User with id %d not found", id)));
    }

    public List<ExpenseItem> getItems() {
        return dao.findAll();
    }

    public ExpenseItem saveItem(ExpenseItem item) {
        return dao.save(item);
    }
    public ExpenseItem updateItem(ExpenseItem item) {
        return dao.save(item);
    }
    public void deleteItemById(int id) {
        dao.deleteById(id);
    }
}
