package com.trg.exception;

public class ExpenseItemNotFoundException extends Exception{
    public ExpenseItemNotFoundException() {
        super();
    }

    public ExpenseItemNotFoundException(String message) {
        super(message);
    }
}
