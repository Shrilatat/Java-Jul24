package com.trg.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import org.springframework.stereotype.Component;

import java.util.Date;

@Entity
@Table(name = "expenses")
public class ExpenseItem {

    @Id
    @GeneratedValue
    int id;
    String expTitle;
    Date expDate;
    double expAmount;

    //cons, get/set, tostring


    public ExpenseItem() {
    }

    public ExpenseItem(int id, String expTitle, Date expDate, double expAmount) {
        this.id = id;
        this.expTitle = expTitle;
        this.expDate = expDate;
        this.expAmount = expAmount;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getExpTitle() {
        return expTitle;
    }

    public void setExpTitle(String expTitle) {
        this.expTitle = expTitle;
    }

    public Date getExpDate() {
        return expDate;
    }

    public void setExpDate(Date expDate) {
        this.expDate = expDate;
    }

    public double getExpAmount() {
        return expAmount;
    }

    public void setExpAmount(double expAmount) {
        this.expAmount = expAmount;
    }

    @Override
    public String toString() {
        return "ExpenseItem{" +
                "id=" + id +
                ", expTitle='" + expTitle + '\'' +
                ", expDate=" + expDate +
                ", expAmount=" + expAmount +
                '}';
    }
}
